package com.day4;

public class RelationOp {

	public static void main(String[] args) {
		int a = 7, b = 3;
		
		boolean bool = a > b;
		System.out.println("a = " + a + ", b = " + b);
		System.out.println("a > b : " + bool);
		System.out.println("a < b : " + (a < b));
		System.out.println("a >= b : " + (a >= b));
		System.out.println("a <= b : "+ (a <= b));
		System.out.println("a == b : " + (a == b));
		System.out.println("a != b : " + (a != b));
		
		/*
		 	비교 연산자 
		 	>, <, >=, <=, ==, !=
		 	
		 	비교 연산자의 결과는 true, false
		 	조건식에 사용
		*/
		

	}

}
