package com.day4;

public class IncrementOp3 {

	public static void main(String[] args) {
		int a = 3, b=3;
		
		System.out.println("a = " + a + ", b = " + b);
		System.out.println("선증가 a = " + ++a);
		System.out.println("후증가 b = " + b++);
		System.out.println("a = " + a + ", b = " + b);
	}

}
