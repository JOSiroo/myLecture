package com.day8;

public class MethodEx {

	public static void main(String[] args) {
		for(int i = 0; i < 5; i++) {
			System.out.print("*");
		}
		
		System.out.println("\nHello");
		
		for(int i = 0; i < 5; i++) {
			System.out.print("*");
		}
		
		System.out.println("\nJAVA");
		
		for(int i = 0; i < 5; i++) {
			System.out.print("*");
		}
		
		System.out.println("\n!!!!");
		
		for(int i = 0; i < 5; i++) {
			System.out.print("*");
		}
		

	}

}
