package com.day9;

public class MethodTest7 {

	public static void main(String[] args) {
		
	}

}
