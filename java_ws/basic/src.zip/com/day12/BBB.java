package com.day12;

public class BBB {
	private int x = 10;
	int y = 20;
	protected int z = 30;
	public int w = 40;
	
	public void showInfo() {
		System.out.println("BBB클래스의 x = " + x);
		System.out.println("y = " + y);
		System.out.println("z = " + z);
		System.out.println("w = " + w + "\n");
	}
}

