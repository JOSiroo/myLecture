package com.day18.ETC;

public class FruitSeller1 {
	public int nam;
	public int change;
	
	FruitSeller1(int nam, int change){
		this.nam = nam;
		this.change = change;
	}

	public int getNam() {
		return nam;
	}

	public void setNam(int nam) {
		this.nam = nam;
	}

	public int getChange() {
		return change;
	}

	public void setChange(int change) {
		this.change = change;
	}
	
}
