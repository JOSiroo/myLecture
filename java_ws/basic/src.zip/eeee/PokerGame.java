package eeee;
import java.util.ArrayList;
import java.util.Collections;

public class PokerGame {
  public static void main(String[] args) {
	  int k = 0;
	  for(int i = 0; i < 4; i++){
			
			for(int j = 0; j < 13; j++){
				
				//cardList[k] = new Card(i, j);
			k++;
			}
			System.out.println(k);
			
  }
  }
  }
