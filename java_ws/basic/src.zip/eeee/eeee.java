package eeee;

import java.util.Scanner;
class MyRectangle{
	int w;
	int h;
	
MyRectangle(int w, int h){
	this.w = w;
	this.h = h;
}

	public int findArea(){
		return w*h;
	}
	public int findGirth(){
		return (w+h)*2;
	}
}
public class eeee {

		public static void main(String[] args) {

			Scanner sc = new Scanner(System.in);
			int w = sc.nextInt();
			int h = sc.nextInt();
			
			MyRectangle rec = new MyRectangle(w, h);
			int area = rec.findArea();
			int girth = rec.findGirth();
			
			System.out.println("넓이 : " + area + ", 둘레 : " + girth);
		}
	}



